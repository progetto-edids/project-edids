package com.nonsense.Dictionary;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class DictionaryTest {

    private Dictionary dictionary;

    @BeforeEach
    void setUp() {
        dictionary = new Dictionary();
    }

    @Test
    void testAddNoun_NewWord() {
        boolean added = dictionary.addNoun("orange");
        assertTrue(added);
    }

    @Test
    void testAddNoun_Duplicate() {
        dictionary.addNoun("apple"); // already exists
        boolean added = dictionary.addNoun("apple");
        assertFalse(added);
    }

    @Test
    void testAddVerb_NewWord() {
        boolean added = dictionary.addVerb("teleport");
        assertTrue(added);
    }

    @Test
    void testAddVerb_Duplicate() {
        dictionary.addVerb("run"); // already exists
        boolean added = dictionary.addVerb("run");
        assertFalse(added);
    }

    @Test
    void testAddAdjective_NewWord() {
        boolean added = dictionary.addAdjective("mysterious");
        assertTrue(added);
    }

    @Test
    void testAddAdjective_Duplicate() {
        dictionary.addAdjective("happy"); // already exists
        boolean added = dictionary.addAdjective("happy");
        assertFalse(added);
    }

    @Test
    void testGetRandomNoun_NotEmpty() {
        String noun = dictionary.getRandomNoun();
        assertNotNull(noun);
        assertFalse(noun.isBlank());
    }

    @Test
    void testGetRandomVerb_NotEmpty() {
        String verb = dictionary.getRandomVerb();
        assertNotNull(verb);
        assertFalse(verb.isBlank());
    }

    @Test
    void testGetRandomAdjective_NotEmpty() {
        String adjective = dictionary.getRandomAdjective();
        assertNotNull(adjective);
        assertFalse(adjective.isBlank());
    }

    @Test
    void testGetRandomNoun_WhenEmpty() {
        Dictionary emptyDict = new Dictionary();
        emptyDict.clearNouns();  // For testing only
        String result = emptyDict.getRandomNoun();
        assertEquals("placeholder", result);
    }

    @Test
    void testGetRandomVerb_WhenEmpty() {
        Dictionary emptyDict = new Dictionary();
        emptyDict.clearVerbs();  // For testing only
        String result = emptyDict.getRandomVerb();
        assertEquals("placeholder", result);
    }

    @Test
    void testGetRandomAdjective_WhenEmpty() {
        Dictionary emptyDict = new Dictionary();
        emptyDict.clearAdjectives();  // For testing only
        String result = emptyDict.getRandomAdjective();
        assertEquals("placeholder", result);
    }

}
